-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 11, 2014 at 06:25 PM
-- Server version: 5.5.25
-- PHP Version: 5.4.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `weather`
--

-- --------------------------------------------------------

--
-- Table structure for table `weather`
--

CREATE TABLE `weather` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `city` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `lat` float(9,6) NOT NULL,
  `lon` float(9,6) NOT NULL,
  `temp` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `select` smallint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `weather`
--

INSERT INTO `weather` (`id`, `city`, `code`, `lat`, `lon`, `temp`, `date`, `select`) VALUES
(1, 'Mexico City', 'mx', 19.432608, -99.133209, '19', '2014-04-11 16:25:04', 1),
(2, 'Los Angeles', 'la', 34.052235, -118.243683, '', '2014-04-11 03:30:02', 0),
(3, 'London', 'lo', 51.508514, -0.125487, '', '2014-04-11 03:30:02', 0),
(4, 'New York', 'ny', 40.714352, -74.005974, '', '2014-04-11 03:30:02', 0),
(5, 'Tokyo', 'to', 35.689487, 139.691711, '9.87', '2014-04-11 16:25:04', 1),
(6, 'Hong Kong', 'hk', 22.396427, 114.109497, '', '2014-04-11 03:30:02', 0),
(7, 'Reykjavik', 're', 64.135338, -21.895210, '', '2014-04-11 16:25:04', 1),
(8, 'Cairo', 'ca', 30.044420, 31.235712, '', '2014-04-11 03:30:02', 0),
(9, 'Moscow', 'mo', 55.755825, 37.617298, '', '2014-04-11 03:30:02', 0),
(10, 'Santiago', 'sa', -33.469120, -70.641998, '', '2014-04-11 03:30:02', 0);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
